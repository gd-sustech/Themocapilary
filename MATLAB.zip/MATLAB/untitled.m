clear; clc; close all;

%% 1. Parameters
% Liquid Properties (Silicone Oil)
mu0 = 0.01;             % Initial dynamic viscosity [Pa.s]
rho = 963;              % Density [kg/m^3]
gamma_0 = 0.021;        % Reference surface tension [N/m]
gamma_T = 0.046e-3;     % Surface tension temperature coefficient [N/m.K]
theta = 11.5 * (pi/180);% Contact angle [rad]
mu_coeff = 0.018;       % Viscosity-temperature coefficient [1/K]

% Geometry and Conditions
H_inlet = 0.25e-3;      % Inlet gap size (2h) [m]
h_in = H_inlet / 2;     % Inlet half-gap height [m]
Angle_deg = 0;          % Wedge angle [degrees]
k = tan(Angle_deg * pi/180); % Channel slope k = -dh/dx
T_grad = 4.3 * 1e3;     % Thermal gradient [K/m]
Phi_deg = 0;          % Tilt angle [degrees]
Phi = Phi_deg * (pi/180); % Tilt angle [rad]
g = 9.81;               % Gravity [m/s^2]

fprintf('Channel Convergence Slope k = %.4f (Angle = %.1f deg)\n', k, Angle_deg);

%% 2. Simulation Setup
T_total = 60;           % Total simulation time [s]
dt = 0.001;             % Time step [s]
N_steps = ceil(T_total / dt);

% Initialize arrays
x_arr = zeros(1, N_steps); 
t_arr = zeros(1, N_steps); 
v_arr = zeros(1, N_steps); 
h_arr = zeros(1, N_steps); 

% Initial state
x_curr = 0;             
t_curr = 0;

%% 3. Main Loop (Euler Method)
for i = 1:N_steps
    % Record current state
    x_arr(i) = x_curr;
    t_arr(i) = t_curr;
    
    % A. Calculate current gap height
    h_x = h_in - k * x_curr;
    h_arr(i) = h_x;
    
    % B. Calculate local physical properties
    % 1. Local viscosity (increases with position/lower temperature)
    mu_x = mu0 * exp(mu_coeff * T_grad * x_curr);
    
    % 2. Local surface tension (increases with position)
    gamma_x = gamma_0 + gamma_T * T_grad * x_curr;
    
    % C. Calculate Force Terms
    % 1. Marangoni Force (Thermocapillary)
    F_mar = h_x * gamma_T * T_grad * cos(theta);
    
    % 2. Wedge Suction Force (Geometric)
    F_wedge = gamma_x * k * cos(theta);
    
    % 3. Gravity Resistance
    F_grav = (h_x^2) * rho * g * sin(Phi);
    
    % D. Calculate Velocity
    v_curr = (1 / (3 * mu_x)) * (F_mar + F_wedge - F_grav);
    v_arr(i) = v_curr;
    
    % E. Update Position
    x_next = x_curr + v_curr * dt;
    
    % Update variables for next step
    x_curr = x_next;
    t_curr = t_curr + dt;
end

%% 4. Plotting
figure('Color', 'w');

% Plot 1: Position vs Time
subplot(2,1,1);
plot(t_arr, x_arr * 1e3, 'b-', 'LineWidth', 2);
xlabel('Time t (s)', 'FontSize', 12);
ylabel('Position x (mm)', 'FontSize', 12);
title(['Liquid Bridge Position (\theta = ' num2str(Angle_deg) '^{\circ})'], 'FontSize', 14);
grid on;

% Plot 2: Velocity vs Time
subplot(2,1,2);
plot(t_arr, v_arr * 1e3, 'r-', 'LineWidth', 2);
xlabel('Time t (s)', 'FontSize', 12);
ylabel('Velocity v (mm/s)', 'FontSize', 12);
title('Migration Velocity', 'FontSize', 14);
grid on;

% Print Summary
fprintf('--- Result Summary ---\n');
fprintf('Final Position: %.2f mm\n', x_curr * 1e3);
if any(v_arr > 0)
    fprintf('Final Velocity: %.2f mm/s\n', v_arr(find(v_arr>0, 1, 'last')) * 1e3);
else
    fprintf('Final Velocity: 0 mm/s\n');
end