% =========================================================================
% MATLAB Code: Average Velocity vs. Tilt Angle Relationship
% Based on Dai et al. (2022) IJHMT Model
% =========================================================================

clear; clc; close all;

%% 1. Parameters (Based on Dai 2022 Experimental Conditions)
% --- Fluid Properties (100 mPa.s Silicone Oil) ---
mu0      = 0.1;          % [Pa.s] 100 mPa.s
mu_coeff = 0.018;        % [1/K] Corrected physical value
rho      = 963;          % [kg/m^3]
gamma_0  = 0.021;        % [N/m]
gamma_T  = 0.046e-3;     % [N/m.K]

% --- Contact Angle & Hysteresis ---
theta_a  = 12 * (pi/180);% [rad] Advancing angle
beta     = 0.04;         % [-] Hysteresis coefficient (Threshold)

% --- Geometry ---
Vol_uL   = 20;           % [uL]
H_gap    = 1.25e-3;      % [m] Gap height
h        = H_gap / 2;    % Half-height
T_grad   = 3 * 1e3;      % [K/m] Thermal Gradient (e.g. 3 K/mm)
g        = 9.81;         % [m/s^2]

% Calculate Diameter
Vol = Vol_uL * 1e-9;
D   = sqrt(2 * Vol / (pi * h));

% --- Drag Correction Factor ---
% Analytical solution for parallel plates is 12.
% For liquid bridges (free surface), it is typically smaller (8~10).
C_drag_geom = 10; 

%% 2. Sweep Tilt Angles
% Define a range of angles (e.g., 0 to 6 degrees)
phi_deg_list = 0 : 0.2 : 6.0; 
v_avg_list   = zeros(size(phi_deg_list));

fprintf('--- Starting Simulation Sweep ---\n');
fprintf('Calculating velocity for %d different angles...\n', length(phi_deg_list));

% Pre-calculate constant force factors
C_drive       = (4 * gamma_T * T_grad * cos(theta_a)) / (pi * rho * h);
C_hyst_factor = (4 * beta * cos(theta_a)) / (pi * rho * h * D);
C_drag_base   = C_drag_geom / (pi * rho * h^2);

% Loop through each angle
for i = 1:length(phi_deg_list)
    phi_deg = phi_deg_list(i);
    Phi_rad = phi_deg * (pi/180);
    
    % Gravity acceleration component (Resistance)
    Acc_grav = g * sin(Phi_rad);
    
    % --- Solver Setup ---
    tspan = [0 60]; % Simulation time: 60s
    y0 = [0; 0];    % Start from rest
    
    ode_system = @(t, y) dynamics_func(t, y, mu0, mu_coeff, T_grad, gamma_0, gamma_T, ...
                                       C_drive, C_hyst_factor, C_drag_base, Acc_grav);
    
    % Solve ODE
    options = odeset('RelTol', 1e-5, 'AbsTol', 1e-8);
    [t, y] = ode45(ode_system, tspan, y0, options);
    
    % --- Calculate Average Velocity ---
    % Definition: Total Displacement / Total Time
    total_disp = y(end, 1);
    total_time = t(end);
    
    % Handle cases where it doesn't move (velocity approx 0)
    if total_disp < 1e-5
        v_avg = 0;
    else
        v_avg = total_disp / total_time;
    end
    
    v_avg_list(i) = v_avg * 1e3; % Convert to mm/s
end

%% 3. Visualization
figure('Color', 'w', 'Position', [200, 200, 600, 500]);

% Plot Data Points
plot(phi_deg_list, v_avg_list, 'ro-', 'LineWidth', 2, 'MarkerFaceColor', 'r', 'MarkerSize', 6);

% Formatting
xlabel('Tilt Angle \phi (deg)', 'FontSize', 12, 'FontWeight', 'bold');
ylabel('Average Velocity (mm/s)', 'FontSize', 12, 'FontWeight', 'bold');
title(['Average Velocity vs. Tilt Angle (G = ' num2str(T_grad/1000) ' K/mm)'], 'FontSize', 14);
grid on;

% Add annotation for Critical Angle
% Find the first angle where velocity drops to near zero
idx_crit = find(v_avg_list <= 0.01, 1);
if ~isempty(idx_crit)
    crit_angle = phi_deg_list(idx_crit);
    xline(crit_angle, 'k--', 'LineWidth', 1.5, 'Label', ['Critical Angle \approx ' num2str(crit_angle, '%.1f') '^\circ']);
    text(crit_angle+0.2, max(v_avg_list)*0.8, 'Migration Stops', 'Color', 'k');
end

% Set limits
xlim([0, max(phi_deg_list)]);
ylim([0, max(v_avg_list)*1.2]);

fprintf('Done. Critical angle found at approx %.1f degrees.\n', crit_angle);

%% 4. Local Dynamics Function
function dydt = dynamics_func(~, y, mu0, mu_coeff, T_grad, gamma_0, gamma_T, ...
                              C_drive, C_hyst_factor, C_drag_base, Acc_grav)
    x_curr = y(1);
    v_curr = y(2);
    
    % Update Local Properties
    mu_x = mu0 * exp(mu_coeff * T_grad * x_curr);
    gamma_x = gamma_0 + gamma_T * T_grad * x_curr;
    
    % Calculate Accelerations
    acc_static = C_drive - (C_hyst_factor * gamma_x) - Acc_grav;
    acc_drag   = (C_drag_base * mu_x) * v_curr;
    
    % Friction Lock Logic (If stationary and drive < resistance, stay stationary)
    if v_curr <= 0 && acc_static <= 0
        dvdt = 0;
        v_curr = 0;
    else
        dvdt = acc_static - acc_drag;
    end
    
    dydt = [v_curr; dvdt];
end