clear; clc; close all;

%% 1. 实验数据读取配置
excel_file = 'experiment_data.xlsx'; 
% Excel 文件列顺序假设 (共12列):
% 20uL: 3.0(t,x), 4.3(t,x), 5.9(t,x)
% 40uL: 3.0(t,x), 4.3(t,x), 5.9(t,x)

try
    raw_exp_data = readmatrix(excel_file);
    fprintf('成功读取 Excel 文件: %s\n', excel_file);
catch
    warning('未找到文件 "%s"。将只运行模拟部分。', excel_file);
    raw_exp_data = [];
end

%% 2. 定义案例参数
common_beta = 0.02; 
common_phi = 0;
common_mu = 0.0;

% Case配置: {体积, 梯度, 颜色, 线型}
% 颜色: Blue=3.0, Green=4.3, Red=5.9
% 线型: Solid=20uL, Dashed=40uL
case_configs = {
    20, 3000, 'b', '-';  % Case 1
    20, 4300, 'g', '-';  % Case 2
    20, 5900, 'r', '-';  % Case 3
    40, 3000, 'b', '--'; % Case 4
    40, 4300, 'g', '--'; % Case 5
    40, 5900, 'r', '--'; % Case 6
};

data_log = struct(); 

%% 3. 绘图初始化
figure('Color', 'w', 'Position', [100, 100, 1000, 700]);
hold on;
h_lines = [];      % 存储模拟线句柄
legend_str = {};   % 存储图例文字

%% 4. 循环处理
for i = 1:size(case_configs, 1)
    V_uL = case_configs{i, 1};
    G_val = case_configs{i, 2};
    p_color = case_configs{i, 3};
    p_line = case_configs{i, 4};
    
    case_name = sprintf('%duL, %.1fK/mm', V_uL, G_val/1000);
    
    % --- A. 理论模拟 ---
    [t, x, ~] = solve_liquid_bridge(common_beta, V_uL, G_val, common_phi, common_mu);
    x_mm = x * 1e3;
    
    % 保存数据
    data_log(i).case_name = case_name;
    data_log(i).sim_t = t;
    data_log(i).sim_x_mm = x_mm;
    
    % 绘制模拟线
    p_sim = plot(t, x_mm, 'LineStyle', p_line, 'Color', p_color, ...
        'LineWidth', 2, 'DisplayName', [case_name ' (Sim)']);
    
    h_lines = [h_lines, p_sim];
    legend_str{end+1} = case_name;
    
    % --- B. 实验数据 (*) ---
    col_idx_t = 2*i - 1;
    col_idx_x = 2*i;
    
    if ~isempty(raw_exp_data) && size(raw_exp_data, 2) >= col_idx_x
        t_e = raw_exp_data(:, col_idx_t);
        x_e = raw_exp_data(:, col_idx_x);
        valid = ~isnan(t_e) & ~isnan(x_e);
        t_e = t_e(valid);
        x_e = x_e(valid);
        
        data_log(i).exp_t = t_e;
        data_log(i).exp_x_mm = x_e;
        
        % 绘制实验点：使用 '*'，参考您的代码风格
        plot(t_e, x_e, '*', 'Color', p_color, ...
            'MarkerSize', 8, 'LineWidth', 1.5, ...
            'HandleVisibility', 'off'); % 不单独加入图例，使用统一说明
    end
end

%% 5. 图形美化
xlabel('Time t (s)', 'FontSize', 12, 'FontWeight', 'bold');
ylabel('Position x (mm)', 'FontSize', 12, 'FontWeight', 'bold');
title('Thermocapillary Migration: Simulation (-) vs Experiment (*)', 'FontSize', 14);

grid on; box on;
xlim([0, 80]); 

% 自动调整 Y 轴
all_max = 0;
for k=1:length(data_log)
    if ~isempty(data_log(k).sim_x_mm), all_max = max(all_max, max(data_log(k).sim_x_mm)); end
    if isfield(data_log, 'exp_x_mm') && ~isempty(data_log(k).exp_x_mm)
        all_max = max(all_max, max(data_log(k).exp_x_mm));
    end
end
if all_max > 0, ylim([0, all_max * 1.15]); end

% --- 自定义组合图例 ---
% 为了让图例清晰，我们只列出6种颜色对应的模拟线，
% 并额外添加3个黑色假图例来解释 线型 和 标记 的含义。

% 1. 线型说明
h_d1 = plot(nan, nan, 'k-', 'LineWidth', 2, 'DisplayName', '20 uL (Solid)');
h_d2 = plot(nan, nan, 'k--', 'LineWidth', 2, 'DisplayName', '40 uL (Dashed)');
% 2. 标记说明 (*)
h_d3 = plot(nan, nan, 'k*', 'MarkerSize', 8, 'LineWidth', 1.5, 'DisplayName', 'Exp Data (*)');

legend([h_lines, h_d1, h_d2, h_d3], ...
       [legend_str, '20 uL (Solid)', '40 uL (Dashed)', 'Exp Data (*)'], ...
       'Location', 'northwest', 'FontSize', 10, 'NumColumns', 2);

hold off;

%% 6. 保存
save('comparison_results_star.mat', 'data_log');
fprintf('绘图完成。\n');