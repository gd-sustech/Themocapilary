function [t, x, v] = solve_liquid_bridge(beta, Vol_uL, T_grad, Phi_deg, mu_coeff)
% SOLVE_LIQUID_BRIDGE_NO_INERTIA 求解忽略惯性项的准稳态动力学方程
% 核心假设：合力为0 (F_drive - F_hyst - F_grav - F_visc = 0)
% 也就是：速度 v 直接由受力平衡决定，无加速过程。

    %% 1. 固定物理参数定义
    mu0     = 0.105;        % [Pa.s]
    rho     = 963;          % [kg/m^3]
    gamma_0 = 0.021;        % [N/m]
    gamma_T = 0.046e-3;     % [N/m.K]
    
    H_gap   = 1.25e-3;      % [m]
    h       = H_gap / 2;    % [m]
    g       = 9.81;         % [m/s^2]
    
    theta_a = 11.5 * (pi/180); 

    %% 2. 几何与单位换算
    Vol = Vol_uL * 1e-9;       
    Phi = Phi_deg * (pi/180);  
    
    % 计算特征直径 D
    D = sqrt(2 * Vol / (pi * h));
    
    %% 3. 计算常数系数 (Force/Mass 形式依然可用，或者理解为 Force 形式)
    % 虽然忽略惯性(质量)，但为了保持系数定义一致性，我们保留原有的系数计算方式。
    % 在准稳态方程中，分子分母同时约去质量 m 并不影响最终速度 v 的计算。
    
    % 驱动力项系数
    C_drive = (gamma_T * T_grad * cos(theta_a)) / (rho *h);
    
    % 滞后阻力项系数
    C_hyst_factor =(4*beta * cos(theta_a)) / (pi*rho * h * D);
    
    % 粘性阻力项系数 (C_drag_base * mu * v = 阻力加速度)
    % 保持您设置的 8
    C_drag_base = 4 / (pi * rho * h^2);
    
    % 重力项
    Acc_grav = g * sin(Phi);
    
    %% 4. 配置 ODE 求解器 (一阶系统)
    % 状态向量 y 现在只有 1 个元素：[位置 x]
    y0 = 0;            % 初始位置 x=0
    tspan = [0 80];    % 仿真时间
    
    options = odeset('RelTol', 1e-6, 'AbsTol', 1e-9);
    
    % 定义匿名函数
    ode_system = @(t, x) dynamics_func_no_inertia(t, x, mu0, mu_coeff, T_grad, gamma_0, gamma_T, ...
                                       C_drive, C_hyst_factor, C_drag_base, Acc_grav, D);
    
    % 求解 (得到的是位置 x)
    [t, x] = ode45(ode_system, tspan, y0, options);
    
    %% 5. 后处理：根据 x 算回 v
    % 因为 ode45 只返回 x，我们需要用同样的公式反推 v 以便输出
    v = zeros(size(x));
    for i = 1:length(x)
        % 调用一次动力学函数获取速度 (因为 dxdt 就是 v)
        v(i) = dynamics_func_no_inertia(t(i), x(i), mu0, mu_coeff, T_grad, gamma_0, gamma_T, ...
                                       C_drive, C_hyst_factor, C_drag_base, Acc_grav, D);
    end
end

%% 6. 局部动力学函数 (一阶：直接返回速度 v)
function dxdt = dynamics_func_no_inertia(~, x_curr, mu0, mu_coeff, T_grad, gamma_0, gamma_T, ...
                              C_drive, C_hyst_factor, C_drag_base, Acc_grav, D)
    
    % A. 更新物性参数
    % 1. 粘度
    mu_x = mu0 * exp(mu_coeff * T_grad * x_curr);
    
    % 2. 滞后阻力对应的表面张力 (后退端 x - D/2)
    gamma_rec = gamma_0 + gamma_T * T_grad * (x_curr - D/2);
    
    % B. 计算净驱动“加速度”（即单位质量的净力）
    % Net_Drive = 驱动 - 滞后 - 重力
    acc_static_net = C_drive - (C_hyst_factor * gamma_rec) - Acc_grav;
    
    % C. 代数求解速度 v
    % 原理：acc_static_net - (C_drag_base * mu_x) * v = 0 (合力为0)
    % 所以：v = acc_static_net / (C_drag_base * mu_x)
    
    % 物理锁定逻辑：如果净驱动力小于等于0，则无法克服静摩擦，速度为0
    if acc_static_net <= 0
        v = 0;
    else
        drag_coeff_effective = C_drag_base * mu_x;
        v = acc_static_net / drag_coeff_effective;
    end
    
    % D. 输出 dx/dt
    dxdt = v;
end