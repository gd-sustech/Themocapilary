function [t, x, v] = solve_liquid_bridge_3D(beta, Vol_uL, T_grad, Phi_deg, mu_coeff)
% SOLVE_LIQUID_BRIDGE_3D
% 基于三维有限体积推导的动力学方程

    %% 1. 物理参数
    mu0     = 0.105;        % [Pa.s]
    rho     = 963;          % [kg/m^3]
    gamma_0 = 0.021;        % [N/m]
    gamma_T = 0.046e-3;     % [N/m.K]
    H_gap   = 1.25e-3;      % [m]
    h       = H_gap / 2;    % [m]
    g       = 9.81;
    theta_a = 13 * (pi/180);

    %% 2. 3D 几何计算
    Vol = Vol_uL * 1e-9;
    Phi = Phi_deg * (pi/180);
    
    % 特征直径 D (来源于体积)
    D = sqrt(2 * Vol / (pi * h));
    
    % 长径比 (Aspect Ratio)
    Lambda = D / (2*h);

    %% 3. 系数计算 (基于 3D 推导方程)
    
    % --- Term 1: 驱动项系数 (与 D 无关) ---
    % a_drive = (4 * gamma_T * G * cos) / (pi * rho * h)
    C_drive_3D = (4 * gamma_T * T_grad * cos(theta_a)) / (pi * rho * h);
    
    % --- Term 2: 滞后项系数 (与 1/D 成正比) ---
    % a_hyst = (Force) / m = (Const * D) / (Const * D^2) = Const / D
    % 代码中 D 在分母上，完美符合推导
    C_hyst_3D = (4 * beta * cos(theta_a)) / (pi * rho * h * D);
    
    % --- Term 3: 粘性阻力系数 (形状因子修正) ---
    % 理论系数 (Infinite Plate)
    Coeff_Theory = 12; 
    
    % 形状修正函数 xi(D): D 越大，阻力越小
    % n = 0.8 是经验拟合指数
    Xi_Shape_Factor = 1 / (1 + 0.5 * Lambda)^0.5; 
    
    % 修正后的阻力常数
    C_drag_effective = Coeff_Theory * Xi_Shape_Factor;
    
    % 转换为代码中的加速度形式: a_drag = (C * mu * v) / (rho * h^2)
    % 注意系数差异：推导中分母是 2*rho*h^2，这里保持量纲一致性即可
    C_drag_3D = C_drag_effective / (pi * pi * rho * h^2); 
    
    % 重力
    Acc_grav = g * sin(Phi);

    %% 4. 求解
    y0 = [0; 0];
    tspan = [0 80];
    options = odeset('RelTol', 1e-6, 'AbsTol', 1e-9);
    
    ode_system = @(t, y) dynamics_func(t, y, mu0, mu_coeff, T_grad, gamma_0, gamma_T, ...
                                       C_drive_3D, C_hyst_3D, C_drag_3D, Acc_grav, D);
                                   
    [t, y] = ode45(ode_system, tspan, y0, options);
    x = y(:, 1);
    v = y(:, 2);
end

function dydt = dynamics_func(~, y, mu0, mu_coeff, T_grad, gamma_0, gamma_T, ...
                              C_drive, C_hyst, C_drag, Acc_grav, D)
    x_curr = y(1);
    v_curr = y(2);
    
    mu_x = mu0 * exp(mu_coeff * T_grad * x_curr);
    
    % 滞后阻力使用后退端张力 (3D推导依然适用)
    gamma_rec = gamma_0 + gamma_T * T_grad * (x_curr - D/2);
    
    acc_static = C_drive - (C_hyst * gamma_rec) - Acc_grav;
    acc_drag   = (C_drag * mu_x) * v_curr;
    
    dvdt = acc_static - acc_drag;
    
    if v_curr <= 0 && acc_static <= 0
        dvdt = 0; v_curr = 0;
    end
    dydt = [v_curr; dvdt];
end